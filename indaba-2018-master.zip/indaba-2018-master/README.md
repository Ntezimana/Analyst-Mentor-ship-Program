# Deep Learning Indaba 2018
  
This repository contains the practical notebooks for the Deep Learning Indaba
2018, held in Stellenbosch South Africa. 

See [www.deeplearningindaba.com](www.deeplearningindaba.com) for more details.

This is not an official Google product.
